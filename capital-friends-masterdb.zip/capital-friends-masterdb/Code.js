/**
 * ============================================================================
 * MASTER MUTUAL FUND DATABASE - STANDALONE SCRIPT
 * ============================================================================
 *
 * This script goes in a SEPARATE Google Sheet (Master Database)
 * NOT in the user template!
 *
 * Purpose:
 * - Fetch mutual fund data from external APIs
 * - Maintain single source of truth for all MF data
 * - Auto-refresh daily with latest NAVs
 * - User templates connect via IMPORTRANGE
 *
 * Setup:
 * 1. Create new Google Sheet
 * 2. Extensions → Apps Script
 * 3. Paste this code
 * 4. Run setupMasterMFDatabase() once
 * 5. Share sheet as "Anyone with link - Viewer"
 *
 * ============================================================================
 */

/**
 * Configuration
 */
const CONFIG = {
  // Sheet names
  dataSheet: 'MF_Data',
  metadataSheet: 'MF_Metadata',

  // API configuration
  apiSource: 'amfi', // Use 'amfi' for ALL schemes (40,000+) - much faster and complete
  amfiNavUrl: 'https://www.amfiindia.com/spages/navall.txt', // Official AMFI source

  // Trigger settings
  refreshHour: 1, // 1 AM (after market close and NAV update)

  // Data columns (matching your structure)
  columns: {
    fundCode: 1,        // A - Fund Code
    fundName: 2,        // B - Fund Name
    category: 3,        // C - Category
    nav: 4,             // D - NAV
    date: 5,            // E - Date
    fundHouse: 6,       // F - Fund House
    type: 7,            // G - Type
    status: 8           // H - Status
  }
};

/**
 * ONE-TIME SETUP - Run this function once to set up everything
 */
function setupMasterMFDatabase() {
  Logger.log('========================================');
  Logger.log('Setting up Master MF Database...');
  Logger.log('========================================');

  try {
    // Step 1: Create data sheet
    Logger.log('Step 1: Creating MF_Data sheet...');
    createDataSheet();
    Logger.log('✓ MF_Data sheet created');

    // Step 2: Create metadata sheet
    Logger.log('Step 2: Creating MF_Metadata sheet...');
    createMetadataSheet();
    Logger.log('✓ MF_Metadata sheet created');

    // Step 3: Fetch initial data
    Logger.log('Step 3: Fetching initial MF data (this may take 2-5 minutes)...');
    refreshMutualFundData();
    Logger.log('✓ Initial data fetched');

    // Step 4: Set up daily trigger
    Logger.log('Step 4: Setting up daily refresh trigger...');
    setupDailyTrigger();
    Logger.log('✓ Daily trigger installed');

    Logger.log('========================================');
    Logger.log('✅ SETUP COMPLETE!');
    Logger.log('========================================');
    Logger.log('Next steps:');
    Logger.log('1. Check MF_Data sheet for mutual fund data');
    Logger.log('2. Share this sheet as "Anyone with link - Viewer"');
    Logger.log('3. Copy the Sheet ID from URL');
    Logger.log('4. Use that ID in user template configuration');
    Logger.log('========================================');

  } catch (error) {
    Logger.log('❌ Error during setup: ' + error.message);
    Logger.log('Stack trace: ' + error.stack);
    throw error;
  }
}

/**
 * Create MF Data sheet with proper structure
 */
function createDataSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(CONFIG.dataSheet);

  // Delete if exists (for fresh setup)
  if (sheet) {
    Logger.log('Sheet already exists, recreating...');
    ss.deleteSheet(sheet);
  }

  // Create new sheet
  sheet = ss.insertSheet(CONFIG.dataSheet);

  // Set headers (matching your column structure)
  const headers = [
    ['Fund Code', 'Fund Name', 'Category', 'NAV', 'Date', 'Fund House', 'Type', 'Status']
  ];

  sheet.getRange(1, 1, 1, 8).setValues(headers);

  // Format headers
  const headerRange = sheet.getRange(1, 1, 1, 8);
  headerRange.setFontWeight('bold')
    .setBackground('#1a202c')
    .setFontColor('#ffffff')
    .setHorizontalAlignment('center')
    .setVerticalAlignment('middle');

  // Set column widths
  sheet.setColumnWidth(1, 100);   // Fund Code
  sheet.setColumnWidth(2, 450);   // Fund Name
  sheet.setColumnWidth(3, 150);   // Category
  sheet.setColumnWidth(4, 100);   // NAV
  sheet.setColumnWidth(5, 100);   // Date
  sheet.setColumnWidth(6, 200);   // Fund House
  sheet.setColumnWidth(7, 120);   // Type
  sheet.setColumnWidth(8, 100);   // Status

  // Freeze header row
  sheet.setFrozenRows(1);

  // Add filter
  sheet.getRange(1, 1, 1, 8).createFilter();

  return sheet;
}

/**
 * Create Metadata sheet for tracking
 */
function createMetadataSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(CONFIG.metadataSheet);

  if (sheet) {
    ss.deleteSheet(sheet);
  }

  sheet = ss.insertSheet(CONFIG.metadataSheet);

  // Set up metadata structure
  sheet.getRange('A1:B1').setValues([['Property', 'Value']]);
  sheet.getRange('A1:B1').setFontWeight('bold').setBackground('#4a5568').setFontColor('#ffffff');

  const metadata = [
    ['Last Updated', ''],
    ['Total Schemes', ''],
    ['API Source', 'AMFI India (Official)'],
    ['Status', 'Active'],
    ['Refresh Schedule', 'Daily at ' + CONFIG.refreshHour + ':00 AM'],
    ['Last Error', '']
  ];

  sheet.getRange(2, 1, metadata.length, 2).setValues(metadata);

  sheet.setColumnWidth(1, 200);
  sheet.setColumnWidth(2, 300);

  return sheet;
}

/**
 * Main function - Refresh mutual fund data
 * Called by daily trigger
 */
function refreshMutualFundData() {
  const startTime = new Date();
  Logger.log('Starting MF data refresh at ' + startTime);

  try {
    // Fetch all MF data from AMFI India (40,000+ schemes)
    const mfData = fetchFromAMFI();

    if (mfData.length === 0) {
      throw new Error('No data fetched from AMFI');
    }

    // Clear existing data and write new data
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CONFIG.dataSheet);
    if (sheet.getLastRow() > 1) {
      sheet.getRange(2, 1, sheet.getLastRow() - 1, 8).clearContent();
    }

    sheet.getRange(2, 1, mfData.length, mfData[0].length).setValues(mfData);

    // Update metadata
    updateMetadata(mfData.length, null);

    const endTime = new Date();
    const duration = (endTime - startTime) / 1000;

    Logger.log(`✅ Successfully refreshed ${mfData.length} schemes in ${duration} seconds`);

  } catch (error) {
    Logger.log('❌ Error refreshing data: ' + error.message);
    updateMetadata(0, error.message);
    sendErrorEmail(error);
    throw error;
  }
}

/**
 * Fetch data from AMFI India (official source)
 * Imports ALL schemes (40,000+) - matches your current NAV.gs implementation
 */
function fetchFromAMFI() {
  Logger.log('Fetching from AMFI India...');

  try {
    const response = UrlFetchApp.fetch(CONFIG.amfiNavUrl);
    const navText = response.getContentText();
    const lines = navText.split('\n');

    const mfData = [];
    let currentFundHouse = '';

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();

      // Skip empty lines
      if (!line) continue;

      // Check if this is a fund house header (no semicolons)
      if (line.indexOf(';') === -1) {
        currentFundHouse = line;
        continue;
      }

      // Split by semicolon
      const parts = line.split(';');

      // Skip invalid rows
      if (parts.length < 5) continue;

      const schemeCode = parts[0] ? parts[0].trim() : '';
      const schemeName = parts[3] ? parts[3].trim() : '';
      const nav = parts[4] ? parts[4].trim() : '';
      const date = parts[5] ? parts[5].trim() : '';

      // Skip rows without essential data
      if (!schemeCode || !schemeName || !nav) continue;

      // Skip AMFI header row
      if (schemeCode.toLowerCase().includes('scheme code') ||
          schemeName.toLowerCase().includes('scheme name')) continue;

      // Determine category and type from scheme name (matching your NAV.gs logic)
      let category = 'Other';
      let type = 'Growth';

      const nameLower = schemeName.toLowerCase();

      // Determine Type (Direct/Regular)
      if (nameLower.includes('direct')) {
        type = 'Direct';
      } else if (nameLower.includes('regular')) {
        type = 'Regular';
      }

      // Determine Category
      if (nameLower.includes('equity') || nameLower.includes('stock')) {
        category = 'Equity';
      } else if (nameLower.includes('debt') || nameLower.includes('bond')) {
        category = 'Debt';
      } else if (nameLower.includes('hybrid') || nameLower.includes('balanced')) {
        category = 'Hybrid';
      } else if (nameLower.includes('liquid') || nameLower.includes('money market')) {
        category = 'Liquid';
      } else if (nameLower.includes('gilt')) {
        category = 'Gilt';
      } else if (nameLower.includes('elss') || nameLower.includes('tax saver')) {
        category = 'ELSS';
      } else if (nameLower.includes('index') || nameLower.includes('etf')) {
        category = 'Index';
      } else if (nameLower.includes('fof') || nameLower.includes('fund of funds')) {
        category = 'FoF';
      }

      mfData.push([
        schemeCode,                     // Fund Code
        schemeName,                     // Fund Name
        category,                       // Category
        parseFloat(nav) || nav,         // NAV
        date,                           // Date
        currentFundHouse,               // Fund House
        type,                           // Type
        'Active'                        // Status
      ]);
    }

    Logger.log(`Successfully fetched ${mfData.length} schemes from AMFI`);
    return mfData;

  } catch (error) {
    Logger.log('Error in fetchFromAMFI: ' + error.message);
    throw error;
  }
}

/**
 * Update metadata sheet
 */
function updateMetadata(schemeCount, errorMessage) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CONFIG.metadataSheet);

  sheet.getRange('B2').setValue(new Date()); // Last Updated
  sheet.getRange('B3').setValue(schemeCount); // Total Schemes

  if (errorMessage) {
    sheet.getRange('B6').setValue(errorMessage); // Last Error
  } else {
    sheet.getRange('B6').setValue('None');
  }
}

/**
 * Set up daily trigger
 */
function setupDailyTrigger() {
  // Delete existing triggers
  const triggers = ScriptApp.getProjectTriggers();
  triggers.forEach(trigger => {
    if (trigger.getHandlerFunction() === 'refreshMutualFundData') {
      ScriptApp.deleteTrigger(trigger);
    }
  });

  // Create new trigger
  ScriptApp.newTrigger('refreshMutualFundData')
    .timeBased()
    .atHour(CONFIG.refreshHour)
    .everyDays(1)
    .create();

  Logger.log(`Trigger set to run daily at ${CONFIG.refreshHour}:00 AM`);
}

/**
 * Send error notification email
 */
function sendErrorEmail(error) {
  try {
    const email = Session.getEffectiveUser().getEmail();
    if (email) {
      MailApp.sendEmail({
        to: email,
        subject: '[MF Master DB] Data Refresh Failed',
        body: `Error occurred while refreshing mutual fund data:\n\n` +
              `Error: ${error.message}\n\n` +
              `Time: ${new Date()}\n\n` +
              `Please check the Apps Script execution log for details.`
      });
    }
  } catch (e) {
    Logger.log('Failed to send error email: ' + e.message);
  }
}

/**
 * Test function - Search for schemes
 */
function testSearch() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CONFIG.dataSheet);
  const data = sheet.getRange(2, 1, Math.min(10, sheet.getLastRow() - 1), 8).getValues();

  Logger.log('Sample schemes:');
  data.forEach((row, index) => {
    Logger.log(`${index + 1}. ${row[1]} (${row[0]}) - NAV: ${row[3]} | Fund House: ${row[5]}`);
  });
}

/**
 * Get sheet URL and ID for documentation
 */
function getSheetInfo() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  Logger.log('========================================');
  Logger.log('MASTER DATABASE INFO:');
  Logger.log('========================================');
  Logger.log('Sheet Name: ' + ss.getName());
  Logger.log('Sheet ID: ' + ss.getId());
  Logger.log('Sheet URL: ' + ss.getUrl());
  Logger.log('========================================');
  Logger.log('Copy the Sheet ID above and use it in user template configuration:');
  Logger.log('MF_INTEGRATION_CONFIG.masterDatabaseId = "' + ss.getId() + '"');
  Logger.log('========================================');
}
