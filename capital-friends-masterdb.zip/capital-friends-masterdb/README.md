# Capital Friends - Master Database

This folder contains the **master database** Apps Script that maintains mutual fund NAV data and stock prices for all Capital Friends users.

## Purpose

This is a **centralized data source** that all user copies of Capital Friends reference via Google Sheets `IMPORTRANGE()` function to get:
- **Mutual Fund NAV (Net Asset Value)** - Daily prices for Indian mutual funds
- **Stock Prices** - Current stock prices for portfolio tracking

## How It Works

1. **User copies** use `IMPORTRANGE()` to pull data from this master spreadsheet
2. **Apps Script** in this project automatically updates prices from external sources
3. **All users** get updated prices without needing API keys or individual data fetching

## Benefits

- **Centralized maintenance** - Update once, all users benefit
- **No API keys needed** - Users don't need to configure anything
- **Automatic updates** - Prices refresh automatically
- **Consistent data** - All users see the same prices

## Apps Script Files

- `Code.js` - Main entry point and utilities
- `MasterDB_StockImport.js` - Stock price import functionality
- `appsscript.json` - Apps Script manifest

## Data Sources

The master database fetches data from:
- Mutual fund NAV data sources (AMFI, etc.)
- Stock price APIs
- Public financial data feeds

## Security & Privacy

- **Read-only for users** - Users can only read data via IMPORTRANGE, not modify
- **No user data stored** - This only contains public market data
- **No personal information** - Only mutual fund codes, stock symbols, and prices

## Development

### Clone from Apps Script
```bash
clasp clone 1bpMXW502yTE18cbJF8eusLousChAEscIo35eLxZyzd78vebt_JF3hTDz
```

### Push changes
```bash
clasp push
```

### Set up triggers
The Apps Script should have time-based triggers to update prices daily/hourly.

## Important Notes

⚠️ **Critical Infrastructure** - This database serves ALL Capital Friends users. Handle with care!

⚠️ **IMPORTRANGE Permissions** - The master spreadsheet must be:
- Published to web OR
- Shared with "Anyone with the link can view"

⚠️ **Update Frequency** - Balance between data freshness and API rate limits

## Related Projects

- **Main Template** (`capital-friends-template/`) - User template that references this DB
- **Web App** (`capital-friends-app/`) - Landing page
- **Documentation** (`docs/`) - Policy pages

## License

MIT License

## Author

**Jagadeesh Manne**
Email: jagadeeshi.k.manne@gmail.com
GitHub: https://github.com/jagadeeshkmanne/capital-friends
Website: https://capitalfriends.in
