/**
 * ============================================================================
 * CODE.GS - Main Webapp Entry Point
 * ============================================================================
 * Capital Friends V2 - Webapp
 *
 * This file handles routing and serves the web application with questionnaire flow.
 */

/**
 * Configuration - UPDATE THESE VALUES BEFORE DEPLOYMENT
 */
const CONFIG = {
  TEMPLATE_SHEET_ID: '1k_GFpn0ZVRNfxBpgFzCU1zvux7apw9axIP5vIn5NR74',  // Template to copy for users
  TEMPLATE_COPY_URL: 'https://docs.google.com/spreadsheets/d/1k_GFpn0ZVRNfxBpgFzCU1zvux7apw9axIP5vIn5NR74/copy',  // Direct copy URL
  ADMIN_SHEET_ID: '16QXJW6PSVP-NRcZV3UIw_xcRAT4bZD5IujzXMxjvy1M',  // Admin sheet for tracking
  APP_VERSION: 'v2.0',
  APP_NAME: 'Capital Friends',
  COPY_NAME_PREFIX: 'CapitalFriends',  // Copy naming: CapitalFriends-20241102_143025
  GITHUB_URL: 'https://github.com/jagadeeshkmanne/capital-friends-v2',
  SUPPORT_EMAIL: 'jagadeesh.k.manne@gmail.com'
};

/**
 * Main entry point for the web app
 */
function doGet(e) {
  try {
    // Check if this is an authorization test request
    if (e.parameter && e.parameter.authorize === 'true') {
      return testWebAppDriveAccess();
    }

    // Always show landing page (simplified - no dashboard)
    return showLandingPage();
  } catch (error) {
    Logger.log('Error in doGet: ' + error.message);
    return showErrorPage(error.message);
  }
}

/**
 * Test Drive access from web app context
 * Visit: YOUR_WEB_APP_URL?authorize=true
 * This will show if DriveApp works in the web app deployment
 */
function testWebAppDriveAccess() {
  try {
    Logger.log('=== Testing Drive Access from Web App Context ===');

    // Try to access template
    const templateFile = DriveApp.getFileById(CONFIG.TEMPLATE_SHEET_ID);
    Logger.log('✅ Template accessed: ' + templateFile.getName());

    // Try to create a copy
    const testCopy = templateFile.makeCopy('WEBAPP-AUTH-TEST-' + new Date().getTime());
    Logger.log('✅ Copy created: ' + testCopy.getId());

    // Try to transfer ownership
    const testEmail = 'jagadeesh.k.manne@gmail.com';
    testCopy.setOwner(testEmail);
    Logger.log('✅ Ownership transferred to: ' + testEmail);

    // Clean up
    DriveApp.getFileById(testCopy.getId()).setTrashed(true);
    Logger.log('✅ Test copy trashed');

    return HtmlService.createHtmlOutput(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Authorization Test - Success</title>
          <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
            .success { color: #22c55e; font-size: 48px; }
            h1 { color: #22c55e; }
            .details { background: #f3f4f6; padding: 15px; border-radius: 8px; margin: 20px 0; }
            .next-steps { background: #dbeafe; padding: 15px; border-radius: 8px; }
            code { background: #f3f4f6; padding: 2px 6px; border-radius: 4px; }
          </style>
        </head>
        <body>
          <div class="success">✅</div>
          <h1>Drive Authorization Successful!</h1>
          <p>The web app can now use DriveApp to create copies and transfer ownership.</p>

          <div class="details">
            <h3>What was tested:</h3>
            <ul>
              <li>✅ Access template file</li>
              <li>✅ Create copy</li>
              <li>✅ Transfer ownership</li>
            </ul>
          </div>

          <div class="next-steps">
            <h3>Next Steps:</h3>
            <ol>
              <li>Go to Apps Script Editor</li>
              <li>Deploy → Manage deployments</li>
              <li>Click edit (pencil icon) on this deployment</li>
              <li>Change "Who has access" to <strong>"Anyone"</strong></li>
              <li>Click "Deploy"</li>
              <li>Visit the normal web app URL (without ?authorize=true)</li>
              <li>Test creating a copy - should work now! ✅</li>
            </ol>
          </div>
        </body>
      </html>
    `);

  } catch (error) {
    Logger.log('❌ ERROR in testWebAppDriveAccess: ' + error.message);
    Logger.log('Stack: ' + error.stack);

    return HtmlService.createHtmlOutput(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Authorization Test - Failed</title>
          <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
            .error { color: #ef4444; font-size: 48px; }
            h1 { color: #ef4444; }
            .details { background: #fee2e2; padding: 15px; border-radius: 8px; margin: 20px 0; }
            .solution { background: #dbeafe; padding: 15px; border-radius: 8px; }
            code { background: #f3f4f6; padding: 2px 6px; border-radius: 4px; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="error">❌</div>
          <h1>Drive Authorization Failed</h1>
          <p>The web app cannot access DriveApp even with "Execute as: Me".</p>

          <div class="details">
            <h3>Error Details:</h3>
            <p><code>${error.message}</code></p>
          </div>

          <div class="solution">
            <h3>Solution:</h3>
            <p>This is a known Google Apps Script limitation. DriveApp doesn't work reliably in web apps.</p>
            <p><strong>Use the /copy URL approach instead:</strong></p>
            <ol>
              <li>The web app redirects to: <code>https://docs.google.com/spreadsheets/d/${CONFIG.TEMPLATE_SHEET_ID}/copy</code></li>
              <li>Google automatically creates the copy in the user's Drive</li>
              <li>User owns it immediately (no transfer needed)</li>
              <li>Works 100% of the time ✅</li>
            </ol>
            <p>This approach is already implemented in the updated LandingPage.html file.</p>
          </div>
        </body>
      </html>
    `);
  }
}

/**
 * Show landing page (public)
 */
function showLandingPage() {
  const template = HtmlService.createTemplateFromFile('LandingPage');
  template.config = CONFIG;

  return template.evaluate()
    .setTitle(CONFIG.APP_NAME + ' - Family Wealth Tracking & Portfolio Rebalancing')
    .setFaviconUrl('https://img.icons8.com/fluency/48/money-bag.png')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * Show error page
 */
function showErrorPage(errorMessage) {
  const template = HtmlService.createTemplateFromFile('ErrorPage');
  template.errorMessage = errorMessage;
  template.config = CONFIG;

  return template.evaluate()
    .setTitle('Error - ' + CONFIG.APP_NAME)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

/**
 * Include HTML files (for modular HTML)
 * Used by landing page to include Questionnaire.html
 */
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}
