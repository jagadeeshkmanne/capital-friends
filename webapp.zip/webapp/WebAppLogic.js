/**
 * ============================================================================
 * WEBAPP LOGIC - SIMPLIFIED VERSION (NO QUESTIONNAIRE)
 * ============================================================================
 *
 * CHANGES:
 * 1. OAuth compliant - uses drive scope
 * 2. No questionnaire - immediate ownership transfer
 * 3. No admin tracking or master sheet dependency
 * 4. Simple timestamp-based naming
 */

/**
 * Track copy request before sending user to /copy URL
 * This logs the request to a tracking sheet so you know who's copying
 */
function trackCopyRequest(userEmail) {
  try {
    log('=== Tracking copy request ===');

    // Get the actual logged-in user's email (Google forces login)
    const actualUserEmail = Session.getActiveUser().getEmail();
    log('Logged-in user: ' + actualUserEmail);
    log('Provided email: ' + userEmail);

    // Use the logged-in email (more reliable than what they typed)
    const emailToTrack = actualUserEmail || userEmail;

    // Validate email
    if (!emailToTrack || !emailToTrack.includes('@')) {
      log('ERROR: Invalid email');
      return {
        success: false,
        error: 'Please sign in with Google to continue.'
      };
    }

    log('Tracking email: ' + emailToTrack);

    // Try to log to admin tracking sheet
    try {
      const adminSheetId = '16QXJW6PSVP-NRcZV3UIw_xcRAT4bZD5IujzXMxjvy1M';
      const ss = SpreadsheetApp.openById(adminSheetId);

      // Try to find or create "Web App Tracking" sheet
      let sheet = ss.getSheetByName('Web App Tracking');
      if (!sheet) {
        // Create new sheet if it doesn't exist
        sheet = ss.insertSheet('Web App Tracking');

        // Add headers
        sheet.appendRow(['Timestamp', 'User Email', 'Status', 'Copy URL']);
        sheet.getRange(1, 1, 1, 4).setFontWeight('bold').setBackground('#4a5568').setFontColor('#ffffff');
      }

      // Append tracking row with the actual logged-in email
      sheet.appendRow([
        new Date(),                     // Timestamp
        emailToTrack,                   // Logged-in email (not what they typed)
        'Copy requested via /copy URL', // Status
        CONFIG.TEMPLATE_COPY_URL        // Copy URL
      ]);

      log('✅ Tracked user in admin sheet: ' + emailToTrack);
    } catch (trackingError) {
      log('⚠️ Tracking failed (non-fatal): ' + trackingError.message);
      // Don't fail - tracking is optional
    }

    // Get total count for display (with base count)
    const BASE_COUNT = 47; // Starting number for social proof
    let totalCopies = BASE_COUNT;
    try {
      const adminSheetId = '16QXJW6PSVP-NRcZV3UIw_xcRAT4bZD5IujzXMxjvy1M';
      const ss = SpreadsheetApp.openById(adminSheetId);
      const sheet = ss.getSheetByName('Web App Tracking');
      if (sheet) {
        const actualCount = sheet.getLastRow() - 1; // Subtract header row
        totalCopies = BASE_COUNT + actualCount;
      }
    } catch (e) {
      log('Could not get total count: ' + e.message);
    }

    // Return the copy URL
    return {
      success: true,
      copyUrl: CONFIG.TEMPLATE_COPY_URL,
      userEmail: userEmail,
      timestamp: new Date().toISOString(),
      totalCopies: totalCopies
    };

  } catch (error) {
    log('❌ ERROR in trackCopyRequest: ' + error.message);
    // Even if tracking fails, still return the copy URL
    return {
      success: true,
      copyUrl: CONFIG.TEMPLATE_COPY_URL,
      error: 'Tracking failed but copy URL generated'
    };
  }
}

/**
 * Get total number of copies created (for display on landing page)
 * Adds a base number to make it look more established
 */
function getTotalCopiesCount() {
  try {
    const BASE_COUNT = 47; // Starting number for social proof
    const adminSheetId = '16QXJW6PSVP-NRcZV3UIw_xcRAT4bZD5IujzXMxjvy1M';
    const ss = SpreadsheetApp.openById(adminSheetId);
    const sheet = ss.getSheetByName('Web App Tracking');

    if (!sheet) {
      return BASE_COUNT; // Show base count even if no tracking sheet yet
    }

    const totalRows = sheet.getLastRow();
    const actualCount = totalRows > 1 ? totalRows - 1 : 0; // Subtract header row
    const displayCount = BASE_COUNT + actualCount;

    log('Total copies count: ' + actualCount + ' (displaying: ' + displayCount + ')');
    return displayCount;

  } catch (error) {
    log('Error getting total count: ' + error.message);
    return BASE_COUNT; // Return base count if error
  }
}

// Questionnaire function removed - ownership transfer now happens immediately in createUserCopy()

/**
 * Get or create "Capital-Friends-Temp" folder in your Drive root
 * This folder stores temporary copies before ownership transfer
 */
function getOrCreateTempFolder() {
  const folderName = 'Capital-Friends-Temp';

  // Check if folder already exists
  const folders = DriveApp.getFoldersByName(folderName);
  if (folders.hasNext()) {
    return folders.next();
  }

  // Create new folder at Drive root
  const newFolder = DriveApp.createFolder(folderName);
  log('Created temp folder: ' + folderName);
  return newFolder;
}

/**
 * Logging helpers
 */
function log(message) {
  console.log('[WebApp] ' + message);
  Logger.log('[WebApp] ' + message);
}

function logError(functionName, error) {
  const errorMsg = '[ERROR in ' + functionName + '] ' + error.message;
  console.error(errorMsg);
  Logger.log(errorMsg);
}

/**
 * TEST FUNCTION - Run this FIRST before deploying web app
 * This ensures YOU have authorized the drive scope
 */
function testDriveAccess() {
  try {
    Logger.log('=== Testing Drive Access ===');

    // Test 1: Can we access the template?
    Logger.log('Test 1: Accessing template file...');
    const templateFile = DriveApp.getFileById(CONFIG.TEMPLATE_SHEET_ID);
    Logger.log('✅ Template accessed: ' + templateFile.getName());

    // Test 2: Can we create a copy?
    Logger.log('Test 2: Creating test copy...');
    const testCopy = templateFile.makeCopy('TEST-Copy-' + new Date().getTime());
    Logger.log('✅ Copy created: ' + testCopy.getId());

    // Test 3: Can we transfer ownership? (using a known email)
    Logger.log('Test 3: Testing ownership transfer...');
    const testEmail = 'jagadeesh.k.manne@gmail.com'; // Your email
    Logger.log('Transferring to: ' + testEmail);

    testCopy.setOwner(testEmail);
    Logger.log('✅ Ownership transfer successful!');

    // Clean up - delete the test copy
    DriveApp.getFileById(testCopy.getId()).setTrashed(true);
    Logger.log('Test copy moved to trash');

    Logger.log('=== All tests passed! ===');
    Logger.log('You are now authorized to use drive scope in the web app.');
    return 'SUCCESS - Drive access is working! You can now deploy the web app.';

  } catch (error) {
    Logger.log('❌ ERROR: ' + error.message);
    Logger.log('Stack trace: ' + error.stack);
    return 'FAILED: ' + error.message;
  }
}

/**
 * TEST WEB APP EXECUTION - Call this from the web app to see who's running the code
 */
function testWebAppExecution() {
  try {
    const result = {
      effectiveUser: Session.getEffectiveUser().getEmail(),
      canAccessDrive: false,
      canAccessTemplate: false,
      deploymentMode: 'unknown'
    };

    // Test Drive access
    try {
      const templateFile = DriveApp.getFileById(CONFIG.TEMPLATE_SHEET_ID);
      result.canAccessTemplate = true;
      result.templateName = templateFile.getName();
    } catch (e) {
      result.driveError = e.message;
    }

    return result;
  } catch (error) {
    return {
      error: error.message,
      stack: error.stack
    };
  }
}

/**
 * TEST COPY CREATION AND TRANSFER - Run this manually to test the complete flow
 */
function testCopyCreation() {
  try {
    Logger.log('=== Testing Copy Creation and Ownership Transfer ===');

    // Test creating a copy and transferring ownership
    Logger.log('Creating test copy...');
    const copyResult = createUserCopy('jagadeesh.k.manne@gmail.com');

    if (!copyResult.success) {
      Logger.log('❌ Failed to create copy: ' + copyResult.error);
      return 'FAILED: ' + copyResult.error;
    }

    Logger.log('✅ Copy created and ownership transferred!');
    Logger.log('Sheet URL: ' + copyResult.sheetUrl);
    Logger.log('Message: ' + copyResult.message);
    return 'SUCCESS - Check your email for ownership notification!';

  } catch (error) {
    Logger.log('❌ ERROR: ' + error.message);
    Logger.log('Stack trace: ' + error.stack);
    return 'FAILED: ' + error.message;
  }
}
