# GitHub Pages Setup for Capital Friends

This folder contains the website files for Google OAuth verification.

## Quick Setup (3 steps)

### Step 1: Customize the Files

Replace these placeholders in all 3 HTML files:

1. **YOUR_WEB_APP_URL_HERE** - Your deployed Apps Script URL
   - Get it from: Apps Script → Deploy → Web app URL
   - Format: `https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec`
   - Files to update: `index.html` (appears twice)

2. **YOUR_EMAIL@gmail.com** - Your contact email
   - Files to update: `privacy-policy.html`, `terms-of-service.html`

3. **YOUR_USERNAME/capital-friends** - Your GitHub repo
   - Files to update: All 3 files

4. **YOUR_JURISDICTION** - Your location (e.g., "the State of California, USA")
   - Files to update: `terms-of-service.html`

### Step 2: Push to GitHub

```bash
cd /Users/jags/Desktop/cfv1
git add docs/
git commit -m "Add GitHub Pages website for OAuth verification"
git push origin main
```

### Step 3: Enable GitHub Pages

1. Go to your repository on GitHub
2. Click **Settings** → **Pages**
3. Under "Source":
   - Branch: **main**
   - Folder: **/docs**
4. Click **Save**
5. Wait 2-3 minutes for deployment

Your website will be live at:
```
https://YOUR_USERNAME.github.io/YOUR_REPO_NAME/
```

## Files in This Folder

- `index.html` - Homepage with app description and "Get Started" button
- `privacy-policy.html` - Privacy policy (required for OAuth verification)
- `terms-of-service.html` - Terms of service (required for OAuth verification)

## How It Works

```
User visits GitHub Pages homepage
        ↓
Reads about Capital Friends
        ↓
Clicks "Launch Capital Friends" button
        ↓
Redirected to your Apps Script web app
        ↓
Uses the actual Capital Friends app
```

## For OAuth Verification

Use these URLs in your Google Cloud OAuth consent screen:

- **Application homepage**: `https://YOUR_USERNAME.github.io/YOUR_REPO_NAME/`
- **Privacy policy**: `https://YOUR_USERNAME.github.io/YOUR_REPO_NAME/privacy-policy.html`
- **Terms of service**: `https://YOUR_USERNAME.github.io/YOUR_REPO_NAME/terms-of-service.html`

## Testing

After enabling GitHub Pages, test your website:

1. Visit your GitHub Pages URL
2. Check all links work (privacy policy, terms, GitHub link)
3. Click "Launch Capital Friends" - should redirect to your Apps Script web app
4. Mobile test: Check it looks good on phone

## Troubleshooting

**404 Error?**
- Wait 2-3 minutes after enabling Pages
- Check branch is "main" and folder is "/docs"
- Verify files are in the docs/ folder in your repo

**Button doesn't redirect?**
- Make sure you replaced `YOUR_WEB_APP_URL_HERE` in index.html
- Deploy your Apps Script as a web app first

**Need help?**
- See full guide: `../webapp-new/GOOGLE_VERIFICATION_COMPLETE_GUIDE.md`
- Check setup guide: `../webapp-new/GITHUB_PAGES_SETUP.md`
