# Google Verification Checklist for Capital Friends

Use this checklist to track your progress through the verification process.

---

## Phase 1: Domain Setup ⏱️ 1-2 hours

- [ ] **Purchase domain** (optional but recommended: ~$12/year)
  - Domain name: _______________________
  - Registrar: Namecheap / Google Domains / Cloudflare

- [ ] **Set up hosting** (GitHub Pages recommended - free)
  - [ ] Enable GitHub Pages in repository settings
  - [ ] Connect custom domain (if purchased)
  - [ ] Add CNAME DNS record

- [ ] **Create required website pages**
  - [ ] `index.html` - Homepage with app description
  - [ ] `privacy-policy.html` - Privacy policy (template provided)
  - [ ] `terms-of-service.html` - Terms of service (template provided)

- [ ] **Customize templates**
  - [ ] Replace `YOUR_EMAIL@gmail.com` with actual email
  - [ ] Replace `YOUR_USERNAME/capital-friends` with GitHub repo
  - [ ] Replace `YOUR_WEB_APP_URL_HERE` with deployed URL
  - [ ] Replace `[YOUR JURISDICTION]` with your location

- [ ] **Test website**
  - [ ] All pages load correctly
  - [ ] Links work between pages
  - [ ] Mobile responsive

---

## Phase 2: Verify Domain Ownership ⏱️ 30 minutes

- [ ] **Go to Google Search Console**: https://search.google.com/search-console

- [ ] **Add property**
  - Domain: _______________________

- [ ] **Complete verification** (choose one method):
  - [ ] HTML file upload
  - [ ] DNS TXT record
  - [ ] Google Analytics
  - [ ] Google Tag Manager

- [ ] **Verification confirmed** ✓

---

## Phase 3: Create Standard Google Cloud Project ⏱️ 15 minutes

- [ ] **Create new project**: https://console.cloud.google.com
  - Project name: `capital-friends-production`
  - Project ID: _______________________
  - Project number: _______________________

- [ ] **Enable required APIs**
  - [ ] Google Sheets API
  - [ ] Google Drive API
  - [ ] Google Apps Script API (if using advanced features)

- [ ] **Switch Apps Script to new project**
  - [ ] Go to script.google.com → Project Settings
  - [ ] Change GCP project number to: _______________________
  - [ ] Confirm switch

- [ ] **Test web app still works** after project switch ✓

---

## Phase 4: Configure OAuth Consent Screen ⏱️ 45 minutes

- [ ] **Go to OAuth consent screen**: Cloud Console → APIs & Services → OAuth consent screen

### App Registration
- [ ] User Type: External
- [ ] Click "Create"

### App Information
- [ ] **App name**: `Capital Friends - Family Wealth Tracking`
- [ ] **User support email**: _______________________
- [ ] **App logo**: Uploaded (120x120px, <1MB, PNG/JPG)
- [ ] **Application homepage**: _______________________
- [ ] **Application privacy policy link**: _______________________
- [ ] **Application terms of service link**: _______________________
- [ ] **Authorized domains**: _______________________

### Scopes
- [ ] Added required scopes:
  - [ ] `https://www.googleapis.com/auth/spreadsheets`
  - [ ] `https://www.googleapis.com/auth/drive.file`
  - [ ] `https://www.googleapis.com/auth/script.external_request` (if needed)
  - [ ] `https://www.googleapis.com/auth/userinfo.email`

### Review
- [ ] All information reviewed and correct
- [ ] Saved to dashboard

---

## Phase 5: Create Demo Video ⏱️ 30 minutes

- [ ] **Record screen capture** showing:
  - [ ] App homepage
  - [ ] Click "Get Started"
  - [ ] OAuth consent screen (clearly visible)
  - [ ] User authorization flow
  - [ ] Enter email and create copy
  - [ ] Complete questionnaire
  - [ ] Show success modal
  - [ ] Open created Google Sheet
  - [ ] Show file ownership

- [ ] **Video specifications**:
  - [ ] Resolution: 720p or 1080p
  - [ ] Duration: 2-3 minutes
  - [ ] Format: MP4/MOV/WebM
  - [ ] Clear audio (optional but helpful)

- [ ] **Upload to YouTube**:
  - [ ] Video uploaded
  - [ ] Set to **Unlisted** (not Private!)
  - [ ] YouTube URL: _______________________

---

## Phase 6: Submit for Verification ⏱️ 15 minutes

### Pre-submission Checklist
- [ ] Domain verified in Search Console ✓
- [ ] Website live with all pages ✓
- [ ] Standard Cloud project created ✓
- [ ] Apps Script switched to new project ✓
- [ ] OAuth consent screen configured ✓
- [ ] Demo video uploaded to YouTube ✓

### Submit Application
- [ ] Go to: Cloud Console → APIs & Services → OAuth consent screen
- [ ] Click **"Submit for Verification"**

### Fill Out Questionnaire

**App description**:
```
Capital Friends is a free, open-source Google Sheets template for family wealth
tracking and portfolio rebalancing. It creates a personalized spreadsheet in the
user's Google Drive with tracking sheets, charts, and automated rebalancing
recommendations. Users receive weekly email alerts based on their financial
security questionnaire answers.
```

**Link to demonstration video**:
```
https://www.youtube.com/watch?v=YOUR_VIDEO_ID
```

**Why do you need sensitive or restricted scopes?**:
```
Sheets API: To create the financial tracking spreadsheet in user's Drive
Drive API: To manage file creation and transfer ownership to the user
User Email: To identify users and send weekly financial security alerts
```

**Your app's homepage URL**:
```
https://YOUR_DOMAIN.com
```

- [ ] All questions answered
- [ ] Submission completed
- [ ] Confirmation email received

---

## Phase 7: Wait for Response ⏱️ 24-72 hours

- [ ] **Submission date**: _______________________
- [ ] **Expected response by**: _______________________

### Monitor Status
- [ ] Check OAuth consent screen page for status updates
- [ ] Monitor email for Google responses
- [ ] Be ready to answer follow-up questions

### Status Updates
- Status: ⬜ Pending / ⬜ Under Review / ⬜ Approved / ⬜ Rejected
- Notes: _______________________

---

## Phase 8: After Approval

- [ ] **Verification approved!** 🎉
- [ ] **Test with new user** - Confirm no unverified warning
- [ ] **Update README.md** - Add "Google Verified" badge
- [ ] **Announce on GitHub** - Update repository description
- [ ] **Tweet/share** - Spread the word!

---

## Information Summary

Fill this out as you go:

| Item | Value |
|------|-------|
| Domain | _______________________ |
| Website URL | _______________________ |
| Privacy Policy URL | _______________________ |
| Terms of Service URL | _______________________ |
| GCP Project Name | capital-friends-production |
| GCP Project Number | _______________________ |
| Support Email | _______________________ |
| Demo Video URL | _______________________ |
| Submission Date | _______________________ |
| Approval Date | _______________________ |

---

## Quick Tips

✅ **Do This:**
- Use a professional email address
- Make privacy policy detailed and honest
- Show FULL OAuth flow in demo video
- Set YouTube video to "Unlisted" (not Private)
- Respond quickly to Google's follow-up questions

❌ **Don't Do This:**
- Don't skip any required fields
- Don't use "localhost" or non-public URLs
- Don't make video Private on YouTube
- Don't request unnecessary scopes
- Don't lie about data usage

---

## Estimated Time Breakdown

| Phase | Time |
|-------|------|
| Domain setup | 1-2 hours |
| Domain verification | 30 minutes |
| Cloud project setup | 15 minutes |
| OAuth consent screen | 45 minutes |
| Demo video | 30 minutes |
| Submit application | 15 minutes |
| **Total** | **3-4 hours** |
| Google review | 24-72 hours |

---

## Need Help?

- **Full Guide**: See [GOOGLE_VERIFICATION_COMPLETE_GUIDE.md](GOOGLE_VERIFICATION_COMPLETE_GUIDE.md)
- **Official Docs**: https://developers.google.com/apps-script/guides/client-verification
- **Support Email**: YOUR_EMAIL@gmail.com

---

**Last Updated**: January 2025
