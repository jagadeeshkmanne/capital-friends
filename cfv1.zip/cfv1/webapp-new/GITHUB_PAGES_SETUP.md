# GitHub Pages Setup for Capital Friends Verification

## Understanding the Two-Part System

Capital Friends uses **TWO separate but connected parts**:

1. **GitHub Pages** - Your public-facing website (for verification)
2. **Google Apps Script** - Your actual web application (the real app)

They work together like this:

```
User Journey:
1. User visits: username.github.io/capital-friends  (GitHub Pages)
2. Reads about the app, privacy policy, terms
3. Clicks "Get Started" button
4. Redirected to: script.google.com/macros/s/ABC123/exec  (Apps Script)
5. Uses the actual Capital Friends web app
```

---

## Step-by-Step GitHub Pages Setup

### Step 1: Create `/docs` Folder in Your Repository

In your local repository:

```bash
cd /Users/jags/Desktop/cfv1
mkdir -p docs
```

### Step 2: Create the Three Required HTML Pages

I'll create these for you with the exact content needed.

#### File 1: `docs/index.html` (Homepage)

This is your marketing page that links to the actual web app.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Capital Friends - Family Wealth Tracking & Portfolio Rebalancing</title>
    <meta name="description" content="Free, open-source family wealth tracking and portfolio rebalancing tool built with Google Sheets">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #1f2937;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            background: white;
            border-radius: 20px;
            padding: 50px;
            box-shadow: 0 25px 70px rgba(0,0,0,0.3);
        }
        header {
            text-align: center;
            margin-bottom: 40px;
        }
        .logo {
            font-size: 60px;
            margin-bottom: 10px;
        }
        h1 {
            color: #10b981;
            margin-bottom: 10px;
            font-size: 2.8em;
            font-weight: 800;
        }
        .tagline {
            font-size: 1.3em;
            color: #6b7280;
            font-weight: 500;
        }
        h2 {
            color: #374151;
            margin-top: 40px;
            margin-bottom: 20px;
            font-size: 1.8em;
            font-weight: 700;
            border-left: 4px solid #10b981;
            padding-left: 15px;
        }
        p {
            margin-bottom: 20px;
            color: #4b5563;
            font-size: 1.05em;
        }
        ul {
            margin: 20px 0 20px 30px;
            color: #4b5563;
        }
        li {
            margin-bottom: 12px;
            font-size: 1.05em;
            line-height: 1.7;
        }
        .btn-primary {
            display: inline-block;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            padding: 18px 40px;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 700;
            font-size: 1.2em;
            margin: 30px 0;
            transition: all 0.3s;
            box-shadow: 0 6px 20px rgba(16,185,129,0.4);
            border: none;
            cursor: pointer;
        }
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(16,185,129,0.5);
        }
        .cta-section {
            text-align: center;
            background: linear-gradient(135deg, #f0fdf4 0%, #d1fae5 100%);
            padding: 40px;
            border-radius: 15px;
            margin: 40px 0;
        }
        .cta-section h2 {
            margin-top: 0;
            border: none;
            padding: 0;
        }
        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        .feature-card {
            background: #f9fafb;
            padding: 25px;
            border-radius: 12px;
            border: 2px solid #e5e7eb;
            transition: all 0.3s;
        }
        .feature-card:hover {
            border-color: #10b981;
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .feature-icon {
            font-size: 40px;
            margin-bottom: 10px;
        }
        .feature-title {
            font-weight: 700;
            color: #1f2937;
            margin-bottom: 8px;
            font-size: 1.1em;
        }
        .feature-desc {
            color: #6b7280;
            font-size: 0.95em;
            margin: 0;
        }
        footer {
            margin-top: 50px;
            padding-top: 30px;
            border-top: 2px solid #e5e7eb;
            text-align: center;
        }
        footer a {
            color: #10b981;
            text-decoration: none;
            margin: 0 15px;
            font-weight: 600;
        }
        footer a:hover {
            text-decoration: underline;
        }
        .badge {
            display: inline-block;
            background: #10b981;
            color: white;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 700;
            margin-left: 10px;
        }
        .security-note {
            background: #fef3c7;
            border: 2px solid #fbbf24;
            border-radius: 10px;
            padding: 20px;
            margin: 30px 0;
        }
        .security-note strong {
            color: #92400e;
            font-size: 1.1em;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">💰</div>
            <h1>Capital Friends</h1>
            <p class="tagline">Free Family Wealth Tracking & Portfolio Rebalancing</p>
        </header>

        <div class="cta-section">
            <h2>🚀 Get Started in 60 Seconds</h2>
            <p>Create your free personalized wealth tracking spreadsheet</p>
            <a href="YOUR_WEB_APP_URL_HERE" class="btn-primary">Launch Capital Friends →</a>
            <p style="margin-top: 15px; font-size: 0.95em; color: #6b7280;">
                ✓ No credit card required &nbsp;&nbsp; ✓ Your data stays private in YOUR Google Drive
            </p>
        </div>

        <h2>What is Capital Friends?</h2>
        <p>
            Capital Friends is a <strong>completely free, open-source</strong> financial management tool
            that helps families track their wealth across multiple accounts, assets, and investments.
            Built entirely with Google Sheets and Apps Script, your data stays 100% private in
            <strong>your own Google Drive</strong>.
        </p>

        <div class="security-note">
            <strong>🔒 Privacy First:</strong> Unlike other financial apps, Capital Friends never stores
            your financial data on our servers. Everything lives in YOUR Google Drive account that only
            YOU control.
        </div>

        <h2>Key Features</h2>
        <div class="features">
            <div class="feature-card">
                <div class="feature-icon">📊</div>
                <div class="feature-title">Complete Wealth Tracking</div>
                <div class="feature-desc">Track bank accounts, investments, real estate, gold, crypto, and more in one place</div>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🎯</div>
                <div class="feature-title">Auto Rebalancing</div>
                <div class="feature-desc">Get automated recommendations to maintain your target portfolio allocation</div>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🛡️</div>
                <div class="feature-title">Security Alerts</div>
                <div class="feature-desc">8-question financial security check with weekly email alerts</div>
            </div>
            <div class="feature-card">
                <div class="feature-icon">📈</div>
                <div class="feature-title">Visual Dashboards</div>
                <div class="feature-desc">Beautiful charts and graphs to understand your wealth at a glance</div>
            </div>
            <div class="feature-card">
                <div class="feature-icon">👨‍👩‍👧‍👦</div>
                <div class="feature-title">Family Focused</div>
                <div class="feature-desc">Designed for families to track joint assets and individual portfolios</div>
            </div>
            <div class="feature-card">
                <div class="feature-icon">💯</div>
                <div class="feature-title">100% Free</div>
                <div class="feature-desc">No subscriptions, no hidden fees, no premium tiers. Forever free.</div>
            </div>
        </div>

        <h2>How It Works</h2>
        <ul>
            <li><strong>Step 1:</strong> Click "Launch Capital Friends" above</li>
            <li><strong>Step 2:</strong> Authorize the app to create a spreadsheet in your Google Drive</li>
            <li><strong>Step 3:</strong> Answer 8 quick security questions (1 minute)</li>
            <li><strong>Step 4:</strong> Your personalized wealth tracking sheet is created instantly!</li>
            <li><strong>Step 5:</strong> Start tracking your family's wealth and get rebalancing recommendations</li>
        </ul>

        <h2>Perfect For</h2>
        <ul>
            <li>💑 Families wanting to organize finances together</li>
            <li>📊 Investors tracking multiple accounts and asset classes</li>
            <li>🎓 People learning about portfolio management and rebalancing</li>
            <li>🔒 Privacy-conscious users who want control over their financial data</li>
            <li>💰 Anyone who wants free, powerful wealth tracking without subscriptions</li>
        </ul>

        <h2>Open Source & Transparent</h2>
        <p>
            Capital Friends is <strong>100% open source</strong>. You can review every line of code on
            <a href="https://github.com/YOUR_USERNAME/capital-friends" target="_blank" style="color: #10b981; font-weight: 600;">GitHub</a>.
            No hidden tracking, no data mining, no surprises.
        </p>

        <h2>Frequently Asked Questions</h2>

        <p><strong>Q: Is this really free?</strong></p>
        <p>A: Yes! 100% free forever. No credit card, no premium plans, no catch.</p>

        <p><strong>Q: Where is my data stored?</strong></p>
        <p>A: Entirely in YOUR Google Drive. We never see or store your financial information.</p>

        <p><strong>Q: What permissions does the app need?</strong></p>
        <p>A: Only permission to create and edit the spreadsheet in your Drive, and to send you weekly email alerts.</p>

        <p><strong>Q: Can I delete my data?</strong></p>
        <p>A: Absolutely! Just delete the spreadsheet from your Google Drive. You have complete control.</p>

        <p><strong>Q: Is my financial data secure?</strong></p>
        <p>A: Yes! Your data never leaves Google's secure infrastructure. It's as secure as Google Drive itself.</p>

        <div class="cta-section">
            <h2>Ready to Take Control of Your Wealth?</h2>
            <p>Join thousands of families tracking their finances with Capital Friends</p>
            <a href="YOUR_WEB_APP_URL_HERE" class="btn-primary">Get Started Free →</a>
        </div>

        <footer>
            <p style="color: #6b7280; margin-bottom: 15px;">
                Made with ❤️ for families who value financial transparency
            </p>
            <div>
                <a href="privacy-policy.html">Privacy Policy</a>
                <a href="terms-of-service.html">Terms of Service</a>
                <a href="https://github.com/YOUR_USERNAME/capital-friends" target="_blank">GitHub</a>
            </div>
            <p style="margin-top: 20px; color: #9ca3af; font-size: 0.9em;">
                © 2025 Capital Friends. Open Source Software.
            </p>
        </footer>
    </div>
</body>
</html>
```

**IMPORTANT:** Replace `YOUR_WEB_APP_URL_HERE` (appears twice) with your actual deployed Apps Script URL like:
```
https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec
```

---

### Step 3: Copy Privacy Policy and Terms of Service

Copy the privacy policy and terms of service HTML files I already created for you:

```bash
# From your terminal
cp /Users/jags/Desktop/cfv1/webapp-new/GOOGLE_VERIFICATION_COMPLETE_GUIDE.md docs/
```

Actually, let me extract just the HTML from those templates into separate files...

---

### Step 4: Enable GitHub Pages

1. **Push your `/docs` folder to GitHub**:
   ```bash
   cd /Users/jags/Desktop/cfv1
   git add docs/
   git commit -m "Add GitHub Pages website for verification"
   git push origin main
   ```

2. **Enable GitHub Pages** in your repository:
   - Go to: `https://github.com/YOUR_USERNAME/YOUR_REPO/settings/pages`
   - Under "Source", select: **main** branch
   - Under "Folder", select: **/docs**
   - Click **Save**

3. **Your website will be live at**:
   ```
   https://YOUR_USERNAME.github.io/YOUR_REPO/
   ```

   Example: `https://johnsmith.github.io/capital-friends/`

---

## Step 5: Connect the Two Parts

### In Your GitHub Pages Homepage

The "Get Started" button links to your Apps Script web app:

```html
<a href="https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec" class="btn-primary">
  Launch Capital Friends →
</a>
```

### In Your OAuth Consent Screen

Use your GitHub Pages URLs:

- **Application homepage**: `https://YOUR_USERNAME.github.io/capital-friends/`
- **Privacy policy**: `https://YOUR_USERNAME.github.io/capital-friends/privacy-policy.html`
- **Terms of service**: `https://YOUR_USERNAME.github.io/capital-friends/terms-of-service.html`

---

## Visual Flow Diagram

```
┌──────────────────────────────────────────────────────────────┐
│                       USER JOURNEY                            │
└──────────────────────────────────────────────────────────────┘

1. Google Search / Social Media
   ↓
2. GitHub Pages Homepage
   https://username.github.io/capital-friends/

   [User reads about the app]
   [User clicks "Get Started" button]
   ↓
3. Apps Script Web App
   https://script.google.com/macros/s/ABC123/exec

   [OAuth consent screen appears]
   [User authorizes app]
   ↓
4. Capital Friends Landing Page
   [User enters email]
   [User completes questionnaire]
   [Spreadsheet created!]
```

---

## Why This Works for Verification

Google requires:
- ✅ **A public homepage** describing your app → GitHub Pages provides this
- ✅ **Privacy policy on a public URL** → GitHub Pages hosts this
- ✅ **Terms of service on a public URL** → GitHub Pages hosts this
- ✅ **Consistent domain** → All three pages on `username.github.io`

Your Apps Script web app doesn't need to change at all! It keeps running on `script.google.com` like it does now.

---

## Summary

| Component | Purpose | URL |
|-----------|---------|-----|
| **GitHub Pages** | Marketing site, privacy policy, terms | `username.github.io/capital-friends/` |
| **Apps Script** | Actual working web app | `script.google.com/macros/s/.../exec` |
| **Connection** | "Get Started" button links from GitHub to Apps Script | User clicks button → redirects |

**They're separate but linked** - like having a restaurant website (GitHub Pages) and the actual restaurant (Apps Script). The website tells people about the restaurant and how to get there!

---

## Next Steps

1. I'll create the actual HTML files in your `/docs` folder
2. You'll replace `YOUR_WEB_APP_URL_HERE` with your deployed Apps Script URL
3. You'll push to GitHub and enable Pages
4. You'll use the GitHub Pages URLs in your OAuth consent screen

Ready for me to create these files?
