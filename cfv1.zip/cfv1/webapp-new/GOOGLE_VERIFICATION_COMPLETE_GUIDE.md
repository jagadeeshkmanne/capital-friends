# Complete Google OAuth Verification Guide for Capital Friends

## Why This Matters

The "This app isn't verified" warning makes users think your app is a scam and destroys trust. **This guide will help you remove that warning completely.**

**Timeline:** 24-72 hours after submission
**Cost:** Free
**User Limit Without Verification:** 100 users maximum

---

## Prerequisites Checklist

Before you start, you need:

- [ ] **A domain you own** (e.g., capitalfriends.com, yourdomain.com)
- [ ] **Domain verification** with Google Search Console
- [ ] **Web hosting** for your domain (GitHub Pages, Netlify, Vercel work fine - all free)
- [ ] **Standard Google Cloud Project** (not the default Apps Script one)
- [ ] **4-5 hours** to complete everything

---

## Phase 1: Domain Setup (1-2 hours)

### Option A: Buy a Domain (Recommended for Trust)

1. **Purchase a domain** (~$12/year):
   - Namecheap, Google Domains, or Cloudflare
   - Example: `capitalfriends.com` or `your-name-finance.com`

2. **Set up free hosting** with GitHub Pages:
   ```bash
   # In your GitHub repository settings
   Settings → Pages → Source: main branch → /docs folder
   ```

3. **Create required pages** in `/docs` folder:
   - `index.html` - Homepage describing Capital Friends
   - `privacy-policy.html` - Privacy policy (template below)
   - `terms-of-service.html` - Terms of service (template below)

4. **Connect your domain**:
   - In GitHub Pages settings, add your custom domain
   - Add DNS records at your domain registrar:
     ```
     Type: CNAME
     Name: www
     Value: your-username.github.io
     ```

### Option B: Use Free GitHub Pages Domain

If you don't want to buy a domain yet:

1. **Enable GitHub Pages** for your repository
2. Your domain will be: `https://your-username.github.io/capital-friends/`
3. **Create required pages** in your repository:
   - `index.html` - Homepage
   - `privacy-policy.html` - Privacy policy
   - `terms-of-service.html` - Terms of service

**Note:** A custom domain looks more professional and trustworthy.

---

## Phase 2: Verify Domain Ownership (30 minutes)

1. **Go to Google Search Console**: https://search.google.com/search-console

2. **Add your domain**:
   - Click "Add Property"
   - Enter your domain (e.g., `capitalfriends.com`)

3. **Verify ownership** using one of these methods:
   - **HTML file upload** (easiest for GitHub Pages)
   - **DNS TXT record** (if you control DNS)
   - **Google Analytics** (if already installed)

4. **Wait for verification** (usually instant, max 24 hours)

---

## Phase 3: Create Standard Google Cloud Project (15 minutes)

Your Apps Script currently uses a "default" project that **cannot be verified**. You need a standard project.

### Step 1: Create New Project

1. Go to: https://console.cloud.google.com
2. Click **"Select a project"** → **"New Project"**
3. **Project name:** `capital-friends-production`
4. **Organization:** Leave as "No organization"
5. Click **"Create"**

### Step 2: Enable Required APIs

1. In your new project, go to **APIs & Services** → **Library**
2. Enable these APIs:
   - Google Sheets API
   - Google Drive API
   - Google Apps Script API

### Step 3: Switch Your Apps Script to New Project

1. Open your Apps Script project: https://script.google.com
2. Go to **Project Settings** (gear icon)
3. Under **Google Cloud Platform (GCP) Project**, click **"Change project"**
4. Enter your new project number (find it in Cloud Console → Dashboard)
5. Click **"Set project"**

**IMPORTANT:** Test your web app after switching to ensure it still works!

---

## Phase 4: Configure OAuth Consent Screen (45 minutes)

1. **Go to Google Cloud Console**: https://console.cloud.google.com
2. Select your `capital-friends-production` project
3. Go to **APIs & Services** → **OAuth consent screen**

### Step 1: App Registration

- **User Type:** External
- Click **"Create"**

### Step 2: App Information

Fill out the form carefully:

**App name:**
```
Capital Friends - Family Wealth Tracking
```

**User support email:**
```
your-email@gmail.com
```

**App logo:** (Optional but recommended)
- Upload a 120x120px PNG logo
- Keep it under 1MB
- Use your app icon or a simple finance-related icon

**Application homepage:**
```
https://capitalfriends.com
```
(or your GitHub Pages URL)

**Application privacy policy link:**
```
https://capitalfriends.com/privacy-policy.html
```

**Application terms of service link:**
```
https://capitalfriends.com/terms-of-service.html
```

**Authorized domains:**
```
capitalfriends.com
```
(Add line by line if multiple)

Click **"Save and Continue"**

### Step 3: Scopes

1. Click **"Add or Remove Scopes"**
2. **Add these scopes** (required for Capital Friends):

```
https://www.googleapis.com/auth/spreadsheets
https://www.googleapis.com/auth/drive.file
https://www.googleapis.com/auth/script.external_request
https://www.googleapis.com/auth/userinfo.email
```

**Why these scopes?**
- `spreadsheets` - Create and edit Google Sheets
- `drive.file` - Manage files created by the app
- `script.external_request` - Make external API calls (if needed)
- `userinfo.email` - Identify the user

3. Click **"Update"** → **"Save and Continue"**

### Step 4: Test Users (Optional)

You can add up to 100 test users before verification. Skip this for now.

Click **"Save and Continue"**

### Step 5: Summary

Review everything and click **"Back to Dashboard"**

---

## Phase 5: Create Required Website Pages (1-2 hours)

### Homepage (index.html)

Create a simple, professional homepage:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Capital Friends - Family Wealth Tracking & Portfolio Rebalancing</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            line-height: 1.6;
            color: #1f2937;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            background: white;
            border-radius: 16px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        h1 {
            color: #10b981;
            margin-bottom: 20px;
            font-size: 2.5em;
        }
        h2 {
            color: #374151;
            margin-top: 30px;
            margin-bottom: 15px;
            font-size: 1.5em;
        }
        p { margin-bottom: 15px; color: #4b5563; }
        ul {
            margin: 15px 0 15px 30px;
            color: #4b5563;
        }
        li { margin-bottom: 10px; }
        .btn {
            display: inline-block;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            padding: 15px 30px;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            margin-top: 20px;
            transition: transform 0.2s;
        }
        .btn:hover { transform: translateY(-2px); }
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
            text-align: center;
            font-size: 0.9em;
            color: #6b7280;
        }
        .footer a {
            color: #10b981;
            text-decoration: none;
            margin: 0 10px;
        }
        .footer a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <h1>💰 Capital Friends</h1>
        <p><strong>Free, open-source family wealth tracking and portfolio rebalancing tool</strong></p>

        <h2>What is Capital Friends?</h2>
        <p>
            Capital Friends is a Google Sheets-based financial management tool that helps families
            track their wealth across multiple accounts, assets, and investments. It provides
            automated portfolio rebalancing recommendations and critical financial security alerts.
        </p>

        <h2>Key Features</h2>
        <ul>
            <li>📊 Track all family assets in one place (bank accounts, investments, real estate, gold, etc.)</li>
            <li>🎯 Automated portfolio rebalancing based on your target allocation</li>
            <li>🛡️ Family financial security questionnaire with weekly email alerts</li>
            <li>📈 Visual dashboards and charts for wealth tracking</li>
            <li>🔒 Your data stays in YOUR Google Drive - we never see it</li>
            <li>💯 100% free and open source</li>
        </ul>

        <h2>How It Works</h2>
        <p>
            When you click "Get Started", Capital Friends creates a personal copy of the
            template Google Sheet in your own Google Drive. You have complete ownership
            and control of your financial data.
        </p>

        <h2>Privacy & Security</h2>
        <ul>
            <li>All data is stored in YOUR Google Drive account</li>
            <li>We never store, access, or see your financial information</li>
            <li>The app only creates and manages files you explicitly request</li>
            <li>Open source code - audit it yourself on GitHub</li>
        </ul>

        <a href="YOUR_WEB_APP_URL_HERE" class="btn">Get Started - Create My Copy</a>

        <div class="footer">
            <a href="privacy-policy.html">Privacy Policy</a> |
            <a href="terms-of-service.html">Terms of Service</a> |
            <a href="https://github.com/YOUR_USERNAME/capital-friends" target="_blank">GitHub</a>
        </div>
    </div>
</body>
</html>
```

**Action:** Replace `YOUR_WEB_APP_URL_HERE` with your actual deployed web app URL.

---

### Privacy Policy (privacy-policy.html)

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - Capital Friends</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            line-height: 1.8;
            color: #1f2937;
            background: #f3f4f6;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #10b981;
            margin-bottom: 10px;
            font-size: 2em;
        }
        h2 {
            color: #374151;
            margin-top: 30px;
            margin-bottom: 15px;
            font-size: 1.3em;
        }
        p, li { margin-bottom: 12px; color: #4b5563; }
        ul { margin-left: 30px; }
        .last-updated {
            color: #6b7280;
            font-size: 0.9em;
            margin-bottom: 30px;
        }
        a { color: #10b981; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Privacy Policy</h1>
        <p class="last-updated"><strong>Last Updated:</strong> January 2025</p>

        <h2>1. Overview</h2>
        <p>
            Capital Friends ("we", "our", or "the app") is a free, open-source financial tracking
            tool built with Google Apps Script. This Privacy Policy explains how we handle your data.
        </p>

        <h2>2. What Data We Collect</h2>
        <p>When you use Capital Friends, we collect:</p>
        <ul>
            <li><strong>Email Address:</strong> Your Google account email to identify you and send weekly reports</li>
            <li><strong>Security Questionnaire Answers:</strong> Your 8 Yes/No answers to financial security questions</li>
            <li><strong>Spreadsheet ID:</strong> The ID of the Google Sheet copy created for you</li>
            <li><strong>Usage Timestamps:</strong> Date and time when you created your copy</li>
        </ul>

        <h2>3. What Data We DO NOT Collect</h2>
        <p>We explicitly DO NOT collect, store, or access:</p>
        <ul>
            <li>Your financial data (account balances, transactions, net worth, etc.)</li>
            <li>Personal financial information entered in your spreadsheet</li>
            <li>Contents of your Google Drive files</li>
            <li>Any data beyond what's listed in Section 2</li>
        </ul>

        <h2>4. How We Use Your Data</h2>
        <p>We use the collected data ONLY for:</p>
        <ul>
            <li><strong>Creating Your Spreadsheet Copy:</strong> To generate a personalized copy in your Drive</li>
            <li><strong>Sending Weekly Emails:</strong> To email you weekly alerts based on your questionnaire answers</li>
            <li><strong>Preventing Duplicates:</strong> To check if you already have a pending copy</li>
            <li><strong>Usage Analytics:</strong> To display total copy count on the landing page</li>
        </ul>

        <h2>5. Where Your Data is Stored</h2>
        <p>
            All your financial data stays in YOUR Google Drive. We store only the minimal data
            mentioned in Section 2 in a Google Sheet admin database that only the app developer can access.
        </p>
        <p><strong>Your Financial Data Location:</strong> 100% in your personal Google Drive account</p>
        <p><strong>Admin Data Location:</strong> A private Google Sheet accessible only by the app developer</p>

        <h2>6. Data Sharing & Third Parties</h2>
        <p><strong>We do NOT sell, rent, or share your data with any third parties.</strong></p>
        <p>The only data sharing that occurs:</p>
        <ul>
            <li><strong>Google Services:</strong> The app runs on Google's infrastructure (Apps Script, Drive, Sheets)</li>
            <li><strong>Email Delivery:</strong> Google's email service sends your weekly reports</li>
        </ul>

        <h2>7. Data Retention & Deletion</h2>
        <ul>
            <li><strong>Your Spreadsheet:</strong> Stored indefinitely in YOUR Google Drive until you delete it</li>
            <li><strong>Admin Records:</strong> Stored indefinitely to support the app's functionality</li>
            <li><strong>Deletion Requests:</strong> Contact us at <strong>YOUR_EMAIL@gmail.com</strong> to request data deletion</li>
        </ul>

        <h2>8. Google API Services User Data Policy</h2>
        <p>
            Capital Friends' use and transfer of information received from Google APIs adheres to
            <a href="https://developers.google.com/terms/api-services-user-data-policy" target="_blank">
            Google API Services User Data Policy</a>, including the Limited Use requirements.
        </p>

        <h2>9. OAuth Scopes & Permissions</h2>
        <p>Capital Friends requests these Google OAuth scopes:</p>
        <ul>
            <li><strong>Google Sheets API:</strong> To create and manage your financial tracking spreadsheet</li>
            <li><strong>Google Drive API:</strong> To create files in your Drive and transfer ownership to you</li>
            <li><strong>User Email:</strong> To identify you and send weekly reports</li>
        </ul>
        <p>
            <strong>Important:</strong> We can only access files that the app creates for you.
            We cannot see any other files in your Google Drive.
        </p>

        <h2>10. Security Measures</h2>
        <ul>
            <li>App runs on Google's secure Apps Script infrastructure</li>
            <li>All data transmission uses HTTPS encryption</li>
            <li>Admin database access restricted to app developer only</li>
            <li>No third-party analytics or tracking scripts</li>
        </ul>

        <h2>11. Your Rights</h2>
        <p>You have the right to:</p>
        <ul>
            <li><strong>Access:</strong> Request a copy of your data stored in our admin database</li>
            <li><strong>Deletion:</strong> Request deletion of your admin records (email us)</li>
            <li><strong>Control:</strong> Delete your spreadsheet copy from your Drive anytime</li>
            <li><strong>Revoke Access:</strong> Revoke app permissions in Google Account settings</li>
        </ul>

        <h2>12. Children's Privacy</h2>
        <p>
            Capital Friends is not intended for users under 18 years old. We do not knowingly
            collect data from children.
        </p>

        <h2>13. Changes to This Policy</h2>
        <p>
            We may update this Privacy Policy occasionally. Changes will be posted on this page
            with an updated "Last Updated" date. Continued use of the app after changes constitutes
            acceptance of the revised policy.
        </p>

        <h2>14. Open Source & Transparency</h2>
        <p>
            Capital Friends is open source. You can review the complete code on
            <a href="https://github.com/YOUR_USERNAME/capital-friends" target="_blank">GitHub</a>
            to verify our privacy practices.
        </p>

        <h2>15. Contact Us</h2>
        <p>For privacy concerns, data requests, or questions:</p>
        <ul>
            <li><strong>Email:</strong> YOUR_EMAIL@gmail.com</li>
            <li><strong>GitHub Issues:</strong> <a href="https://github.com/YOUR_USERNAME/capital-friends/issues" target="_blank">Report an issue</a></li>
        </ul>

        <p style="margin-top: 40px; text-align: center;">
            <a href="index.html">← Back to Home</a> |
            <a href="terms-of-service.html">Terms of Service</a>
        </p>
    </div>
</body>
</html>
```

**Actions to customize:**
1. Replace `YOUR_EMAIL@gmail.com` with your actual email
2. Replace `YOUR_USERNAME/capital-friends` with your GitHub repository

---

### Terms of Service (terms-of-service.html)

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms of Service - Capital Friends</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            line-height: 1.8;
            color: #1f2937;
            background: #f3f4f6;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #10b981;
            margin-bottom: 10px;
            font-size: 2em;
        }
        h2 {
            color: #374151;
            margin-top: 30px;
            margin-bottom: 15px;
            font-size: 1.3em;
        }
        p, li { margin-bottom: 12px; color: #4b5563; }
        ul { margin-left: 30px; }
        .last-updated {
            color: #6b7280;
            font-size: 0.9em;
            margin-bottom: 30px;
        }
        a { color: #10b981; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Terms of Service</h1>
        <p class="last-updated"><strong>Last Updated:</strong> January 2025</p>

        <h2>1. Acceptance of Terms</h2>
        <p>
            By accessing and using Capital Friends ("the app"), you agree to be bound by these
            Terms of Service. If you do not agree to these terms, do not use the app.
        </p>

        <h2>2. Description of Service</h2>
        <p>
            Capital Friends is a free, open-source financial tracking tool built with Google Apps Script.
            The app creates a Google Sheet template copy in your Google Drive to help you track family
            wealth, manage portfolio allocation, and receive financial security alerts.
        </p>

        <h2>3. User Eligibility</h2>
        <ul>
            <li>You must be at least 18 years old to use this app</li>
            <li>You must have a valid Google account</li>
            <li>You must comply with all applicable laws and regulations</li>
        </ul>

        <h2>4. User Responsibilities</h2>
        <p>You agree to:</p>
        <ul>
            <li>Provide accurate information when using the app</li>
            <li>Maintain the security of your Google account</li>
            <li>Use the app for lawful purposes only</li>
            <li>Not attempt to hack, reverse-engineer, or abuse the app</li>
            <li>Not create excessive copies to overload the system</li>
        </ul>

        <h2>5. Financial Disclaimer</h2>
        <p><strong>IMPORTANT: Capital Friends is NOT financial advice.</strong></p>
        <ul>
            <li>This app is a tracking tool only - not a financial advisor</li>
            <li>Portfolio rebalancing suggestions are algorithmic, not personalized advice</li>
            <li>Always consult a licensed financial advisor for investment decisions</li>
            <li>We are not responsible for financial losses resulting from app use</li>
            <li>Past performance does not guarantee future results</li>
        </ul>

        <h2>6. Data Ownership & Control</h2>
        <ul>
            <li>You own 100% of your financial data entered in your spreadsheet</li>
            <li>Your data stays in YOUR Google Drive - we do not store it</li>
            <li>You can delete your spreadsheet copy anytime</li>
            <li>You can revoke app permissions in your Google Account settings anytime</li>
        </ul>

        <h2>7. No Warranty</h2>
        <p>
            Capital Friends is provided "AS IS" without warranties of any kind, either express or implied,
            including but not limited to:
        </p>
        <ul>
            <li>Accuracy of calculations or recommendations</li>
            <li>Uninterrupted or error-free operation</li>
            <li>Fitness for a particular purpose</li>
            <li>Data loss prevention</li>
        </ul>

        <h2>8. Limitation of Liability</h2>
        <p>
            To the maximum extent permitted by law, Capital Friends and its developer shall not be
            liable for any:
        </p>
        <ul>
            <li>Direct, indirect, incidental, or consequential damages</li>
            <li>Financial losses from using or inability to use the app</li>
            <li>Data loss or corruption</li>
            <li>Investment decisions made based on app output</li>
        </ul>

        <h2>9. Third-Party Services</h2>
        <p>
            Capital Friends relies on Google's services (Apps Script, Drive, Sheets, Gmail).
            You agree to Google's terms of service:
        </p>
        <ul>
            <li><a href="https://policies.google.com/terms" target="_blank">Google Terms of Service</a></li>
            <li><a href="https://policies.google.com/privacy" target="_blank">Google Privacy Policy</a></li>
        </ul>

        <h2>10. Service Availability</h2>
        <ul>
            <li>The app may be unavailable due to maintenance or technical issues</li>
            <li>We may modify or discontinue features at any time</li>
            <li>Google may impose usage limits on Apps Script projects</li>
            <li>We reserve the right to terminate service for abuse</li>
        </ul>

        <h2>11. Intellectual Property</h2>
        <ul>
            <li>Capital Friends is open source under the MIT License</li>
            <li>You may modify and distribute the code per the license terms</li>
            <li>The "Capital Friends" name and branding remain our property</li>
        </ul>

        <h2>12. Privacy</h2>
        <p>
            Your use of Capital Friends is also governed by our
            <a href="privacy-policy.html">Privacy Policy</a>. Please review it to understand
            how we handle your data.
        </p>

        <h2>13. Modifications to Terms</h2>
        <p>
            We may update these Terms of Service at any time. Changes will be posted on this page
            with an updated "Last Updated" date. Continued use after changes constitutes acceptance.
        </p>

        <h2>14. Termination</h2>
        <p>You may stop using the app anytime by:</p>
        <ul>
            <li>Deleting your spreadsheet copy from Google Drive</li>
            <li>Revoking app permissions in your Google Account settings</li>
        </ul>

        <h2>15. Governing Law</h2>
        <p>
            These Terms shall be governed by and construed in accordance with the laws of
            [YOUR JURISDICTION], without regard to its conflict of law provisions.
        </p>

        <h2>16. Contact & Dispute Resolution</h2>
        <p>For questions, concerns, or disputes:</p>
        <ul>
            <li><strong>Email:</strong> YOUR_EMAIL@gmail.com</li>
            <li><strong>GitHub Issues:</strong> <a href="https://github.com/YOUR_USERNAME/capital-friends/issues" target="_blank">Report an issue</a></li>
        </ul>

        <h2>17. Severability</h2>
        <p>
            If any provision of these Terms is found to be unenforceable, the remaining provisions
            will continue in full force and effect.
        </p>

        <h2>18. Entire Agreement</h2>
        <p>
            These Terms of Service, together with our Privacy Policy, constitute the entire agreement
            between you and Capital Friends regarding use of the app.
        </p>

        <p style="margin-top: 40px; text-align: center;">
            <a href="index.html">← Back to Home</a> |
            <a href="privacy-policy.html">Privacy Policy</a>
        </p>
    </div>
</body>
</html>
```

**Actions to customize:**
1. Replace `[YOUR JURISDICTION]` with your country/state (e.g., "the State of California, USA")
2. Replace `YOUR_EMAIL@gmail.com` with your actual email
3. Replace `YOUR_USERNAME/capital-friends` with your GitHub repository

---

## Phase 6: Create Demo Video (30 minutes)

Google requires a **YouTube video** showing your app in action.

### What to Include:

1. **App Launch** (10 seconds):
   - Show your homepage
   - Click "Get Started"

2. **OAuth Flow** (20 seconds):
   - Show the OAuth consent screen
   - Click through permissions
   - Show app name and scopes clearly

3. **App Functionality** (60 seconds):
   - Enter email and click "Create My Copy"
   - Show questionnaire modal
   - Answer all 8 questions
   - Show success modal
   - Open the created Google Sheet in Drive
   - Briefly show the sheet features

4. **Ownership Transfer** (10 seconds):
   - Show that the sheet is in YOUR Drive
   - Show file permissions (you're the owner)

### Recording Tips:

- **Use free screen recording**: OBS Studio, Loom, or QuickTime (Mac)
- **Resolution**: 720p or 1080p
- **Duration**: 2-3 minutes max
- **Audio**: Optional but helpful (explain what you're doing)
- **Upload to YouTube**: Set to "Unlisted" (not Private, not Public)

**Example Script:**
```
"Hi, this is Capital Friends, a free wealth tracking tool.
I'll click Get Started... now I'll authorize the app...
entering my email... answering security questions...
and here's my personal copy created in my Drive.
I'm the owner and all my data stays private."
```

---

## Phase 7: Submit for Verification (15 minutes)

Now you're ready to submit!

### Step 1: Final Checklist

Verify everything is ready:

- [ ] Domain verified in Google Search Console
- [ ] Website live with homepage, privacy policy, terms of service
- [ ] Standard Google Cloud project created
- [ ] Apps Script switched to new project
- [ ] OAuth consent screen fully configured
- [ ] Demo video uploaded to YouTube (unlisted)

### Step 2: Submit Application

1. Go to **Google Cloud Console** → **APIs & Services** → **OAuth consent screen**
2. Review all information one final time
3. Click **"Submit for Verification"**
4. Fill out the verification form:

**App verification questionnaire:**

- **App description**:
  ```
  Capital Friends is a free, open-source Google Sheets template for family wealth
  tracking and portfolio rebalancing. It creates a personalized spreadsheet in the
  user's Google Drive with tracking sheets, charts, and automated rebalancing
  recommendations. Users receive weekly email alerts based on their financial
  security questionnaire answers.
  ```

- **Link to demonstration video**:
  ```
  https://www.youtube.com/watch?v=YOUR_VIDEO_ID
  ```

- **Why do you need sensitive or restricted scopes?**:
  ```
  Sheets API: To create the financial tracking spreadsheet in user's Drive
  Drive API: To manage file creation and transfer ownership to the user
  User Email: To identify users and send weekly financial security alerts
  ```

- **Your app's homepage URL**:
  ```
  https://capitalfriends.com
  ```

5. Click **"Submit"**

### Step 3: Wait for Response

- **Expected timeline**: 24-72 hours
- **Check status**: OAuth consent screen page shows verification status
- **Be ready to respond**: Google may ask follow-up questions via email

---

## Phase 8: After Approval

Once approved:

1. ✅ **Test with a new user** - Have a friend try the app
2. ✅ **No more unverified warning** - Users will see verified consent screen
3. ✅ **100+ user limit removed** - Unlimited users can now access your app
4. ✅ **Update your README** - Add "Google Verified" badge

---

## Troubleshooting Common Issues

### Issue: "Domain not verified"
**Solution:** Complete Google Search Console verification first (Phase 2)

### Issue: "Invalid privacy policy URL"
**Solution:** Make sure URL is publicly accessible (not 404) and on authorized domain

### Issue: "Redirect URI mismatch"
**Solution:** Apps Script handles this automatically, but if you see errors, add:
```
https://script.google.com/macros/d/{SCRIPT_ID}/usercallback
```
to OAuth redirect URIs

### Issue: "Scopes not matching"
**Solution:** Copy exact scopes from Apps Script → Project Settings → Scopes

### Issue: "Demo video not acceptable"
**Solution:** Ensure video clearly shows:
- OAuth consent screen with app name
- Full permission flow
- Actual app functionality
- YouTube link is "Unlisted" (not Private)

### Issue: Verification rejected
**Solution:** Check rejection email for specific reasons. Common fixes:
- Make privacy policy more detailed
- Show clearer scope justification
- Improve demo video clarity
- Add more homepage content

---

## Alternative: Internal Use Only

If you only want to share Capital Friends with people in your Google Workspace organization:

1. **OAuth Consent Screen** → Select **"Internal"** instead of "External"
2. **No verification needed!** - Internal apps are automatically trusted
3. **Limitation**: Only users in your Workspace domain can access it

---

## Cost Summary

| Item | Cost | Notes |
|------|------|-------|
| Domain (optional) | $12/year | Recommended but not required |
| Hosting | $0 | Use GitHub Pages (free) |
| Google Cloud Project | $0 | Free tier (no charges for Apps Script) |
| Verification | $0 | Completely free process |
| **Total** | **$0-12/year** | Only domain is optional cost |

---

## Questions?

- **Email:** YOUR_EMAIL@gmail.com
- **GitHub Issues:** https://github.com/YOUR_USERNAME/capital-friends/issues

---

## Summary: What This Achieves

Before verification:
- ❌ "This app isn't verified" scary warning
- ❌ Users think it's a scam
- ❌ Limited to 100 users
- ❌ Low trust

After verification:
- ✅ Professional, verified OAuth consent screen
- ✅ Users trust your app
- ✅ Unlimited users
- ✅ Builds credibility
- ✅ Looks like a real product

**The effort is worth it!** You're transforming Capital Friends from looking like a scam to looking like a legitimate, professional financial tool.
