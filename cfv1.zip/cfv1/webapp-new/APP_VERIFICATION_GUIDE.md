# Google Apps Script - App Verification Guide

When you deploy your Capital Friends web app, users may see "This app isn't verified" warning. Here's how to handle it.

## 🔍 Why This Happens

Google shows this warning when:
1. Your app accesses user data (Drive, Sheets, Gmail)
2. You're sharing it publicly ("Anyone" can access)
3. The app hasn't gone through Google's OAuth verification process

## 🎯 Two Solutions

### Option 1: Users Can Bypass (Quick, Free)

**Best for:**
- Small projects
- Personal use
- Friends & family
- Testing

**How users bypass the warning:**

1. User opens your web app URL
2. Clicks "Get My Free Copy"
3. Sees "This app isn't verified" warning
4. Click **"Advanced"** (at the bottom left)
5. Click **"Go to Capital Friends (unsafe)"**
6. Click **"Allow"** to grant permissions
7. Done! App works normally

**Instructions for users:**

```
When you see "This app isn't verified":

1. Click "Advanced" (bottom left)
2. Click "Go to Capital Friends (unsafe)"
3. Click "Allow"

This is safe - the app runs in YOUR Google Drive.
No data is collected or shared.
```

---

### Option 2: Get Google Verification (Official, Complex)

**Best for:**
- Public apps with many users (100+)
- Professional products
- Commercial use

**Requirements:**
- Google Cloud Project (free)
- Privacy Policy URL
- Terms of Service URL
- YouTube demo video showing your app
- Homepage URL
- Support email
- OAuth consent screen configured
- **Review time: 1-6 weeks**

**Steps:**

#### Step 1: Create Google Cloud Project

1. Go to https://console.cloud.google.com
2. Click "New Project"
3. Name: "Capital Friends V2"
4. Click "Create"

#### Step 2: Enable APIs

1. Go to "APIs & Services" → "Library"
2. Enable these APIs:
   - Google Drive API
   - Google Sheets API
   - Gmail API (if sending emails)

#### Step 3: Configure OAuth Consent Screen

1. Go to "APIs & Services" → "OAuth consent screen"
2. Select **"External"** (for public apps)
3. Fill in:
   - App name: Capital Friends
   - User support email: your@email.com
   - Developer contact: your@email.com
   - App logo: Upload a logo (120x120 pixels)
   - Application home page: Your GitHub URL or website
   - Privacy policy: Required (see template below)
   - Terms of service: Required (see template below)

4. Scopes - Add these:
   ```
   https://www.googleapis.com/auth/drive.file
   https://www.googleapis.com/auth/spreadsheets
   https://www.googleapis.com/auth/script.external_request
   ```

5. Test users (optional):
   - Add emails of people who can test before verification

#### Step 4: Submit for Verification

1. Go to "OAuth consent screen"
2. Click "Publish App"
3. Fill out verification questionnaire:
   - Upload demo video (YouTube, unlisted)
   - Explain why you need each permission
   - Provide homepage URL
   - Confirm privacy policy

4. Submit and wait (1-6 weeks)

---

## 📝 Required Documents

### Privacy Policy Template

```markdown
# Privacy Policy for Capital Friends

Last Updated: [Date]

## Overview
Capital Friends is a Google Sheets-based portfolio tracker. Your data stays 100% in YOUR Google Drive.

## Data Collection
We DO NOT collect, store, or access any of your data. The spreadsheet is created directly in your Google Drive account.

## Data Usage
The app only:
- Creates a copy of a template spreadsheet in your Drive
- Reads your email address for tracking copies created
- Does NOT access your financial data
- Does NOT store data on external servers

## Data Storage
All your financial data is stored in YOUR Google Drive. We have ZERO access to it.

## Third-Party Sharing
We do NOT share any data with third parties. There is no data to share.

## Your Rights
You can delete the spreadsheet from your Drive at any time. You own all your data.

## Contact
For questions: your@email.com

## Changes
We will update this policy if needed and notify users via GitHub.
```

Save as: `PRIVACY_POLICY.md` in your GitHub repo

### Terms of Service Template

```markdown
# Terms of Service for Capital Friends

Last Updated: [Date]

## Acceptance
By using Capital Friends, you agree to these terms.

## Service Description
Capital Friends provides a Google Sheets template for portfolio tracking. The spreadsheet is free and open-source.

## User Responsibilities
- You are responsible for your financial data accuracy
- You must keep your Google account secure
- You use this tool at your own risk

## No Warranties
This tool is provided "as is" without warranties. We are not financial advisors.

## Limitation of Liability
We are not liable for any financial decisions made using this tool.

## Changes
We may update these terms. Check GitHub for updates.

## Contact
Questions: your@email.com
```

Save as: `TERMS_OF_SERVICE.md` in your GitHub repo

---

## 🎥 Demo Video Requirements

For verification, you need a YouTube video showing:

1. **Homepage** (10 seconds)
   - Show your landing page
   - Point out "Get My Free Copy" button

2. **OAuth Flow** (30 seconds)
   - Click button → Email input
   - Show permission screen
   - What permissions are requested and WHY

3. **App Functionality** (60 seconds)
   - Show the created spreadsheet
   - Demonstrate key features
   - Prove data stays in user's Drive

4. **Privacy** (20 seconds)
   - Show that data is in user's Drive
   - No backend server
   - No data collection

**Total: 2 minutes max**

Upload to YouTube as **"Unlisted"** (not private, not public)

---

## 🚀 Recommended Approach

### For Most Users: **Option 1** (Bypass Warning)

**Reasons:**
- ✅ Free
- ✅ Instant (no waiting)
- ✅ Simple for users (2 clicks)
- ✅ Works perfectly
- ✅ No maintenance

**Just add this to your README:**

```markdown
## ⚠️ "Unverified App" Warning

When you first use this app, Google shows a warning because the app
accesses your Drive. This is normal for Google Apps Script web apps.

**To proceed:**
1. Click "Advanced"
2. Click "Go to Capital Friends (unsafe)"
3. Click "Allow"

**Is it safe?**
✅ Yes! The spreadsheet is created in YOUR Drive
✅ We have ZERO access to your data
✅ Open-source - you can review the code
✅ No backend servers - everything runs in Google's infrastructure
```

---

### For Large-Scale Apps: **Option 2** (Full Verification)

Only do this if:
- You have 100+ users
- You're running a business
- You can wait 1-6 weeks
- You can maintain privacy policy/TOS

---

## 📋 Quick Start (Recommended)

**Today:**
1. Add "Unverified App" instructions to your README
2. Deploy your web app as "Anyone can access"
3. Test with yourself and a few friends
4. Users click "Advanced" → "Go to [app] (unsafe)"

**Later (if needed):**
- If you get 100+ users
- Consider Option 2 (verification)
- But honestly, most small apps never need it

---

## ❓ Common Questions

**Q: Will users trust an "unverified" app?**
A: If you explain it's normal for Google Apps Script, yes. Many popular open-source apps are unverified.

**Q: Can I avoid the warning completely?**
A: Only by:
  1. Getting verified (Option 2)
  2. OR restricting to "Only people in your organization" (kills public access)

**Q: Does "unsafe" mean it's actually unsafe?**
A: No! It just means Google hasn't verified it. Your app runs entirely in Google's infrastructure.

**Q: How long does verification take?**
A: 1-6 weeks, sometimes longer. And they can reject you.

**Q: What if Google rejects my verification?**
A: Users can still use the app by clicking "Advanced". Verification is optional.

---

## 🎯 Summary

**For Capital Friends (open-source, free, small-scale):**

✅ **Use Option 1** (users bypass warning)
- Add clear instructions in README
- Explain it's safe
- 2-click bypass process
- Works immediately

❌ **Skip Option 2** (verification) unless:
- You have 100+ users
- You're commercializing it
- You can wait weeks/months

---

## 📚 Resources

- [Google OAuth Verification Docs](https://support.google.com/cloud/answer/13463073)
- [Apps Script Authorization](https://developers.google.com/apps-script/guides/services/authorization)
- [OAuth Consent Screen](https://console.cloud.google.com/apis/credentials/consent)

---

**Bottom Line:** For 99% of open-source projects like yours, just add clear instructions for users to bypass the warning. It's normal and safe!
