# Capital Friends V2 - Web App

Clean, production-ready web app for creating and distributing Capital Friends spreadsheet copies.

## 📦 Files

### Core Files (4 total)

1. **Code.gs** - Main entry point
   - Routes requests to landing page
   - Handles configuration
   - Includes helper functions

2. **WebAppLogic.gs** - Backend logic
   - `createUserCopy()` - Creates copy and checks for existing pending copies
   - `saveQuestionnaireAndTransfer()` - Saves questionnaire and transfers ownership
   - `checkExistingPendingCopy()` - Prevents duplicate pending copies
   - `fixAdminSheetHeaders()` - One-time header fix for admin sheet
   - All tracking and database functions

3. **LandingPage.html** - Main landing page
   - Professional dark theme with green accents
   - Inline questionnaire flow
   - Success modal with score display
   - Copy count tracking
   - Responsive design

4. **Questionnaire.html** - Security questionnaire modal
   - 8 questions with inline Yes/No buttons
   - Compact design, no scrollbar
   - Matches main webapp theme
   - Auto-resets after completion

## 🚀 Deployment

### Prerequisites

Update these values in `Code.gs`:

```javascript
const CONFIG = {
  MASTER_SHEET_ID: 'YOUR_ADMIN_SHEET_ID',      // Admin sheet that tracks users
  TEMPLATE_SHEET_ID: 'YOUR_TEMPLATE_SHEET_ID', // Template to copy for users
  APP_VERSION: 'v2.0',
  APP_NAME: 'Capital Friends',
  COPY_NAME_PREFIX: 'CapitalFriends',
  GITHUB_URL: 'https://github.com/YOUR_USERNAME/capital-friends-v2',
  SUPPORT_EMAIL: 'your@email.com'
};
```

### Deploy Steps

1. **Create Apps Script Project**
   - Go to https://script.google.com
   - Click "New Project"
   - Name it "Capital Friends V2"

2. **Copy Files**
   - Code.gs → Create new script file "Code"
   - WebAppLogic.gs → Create new script file "WebAppLogic"
   - LandingPage.html → Create new HTML file "LandingPage"
   - Questionnaire.html → Create new HTML file "Questionnaire"

3. **Fix Admin Sheet Headers (One-Time)**
   - In Apps Script editor, run: `fixAdminSheetHeaders()`
   - This fixes Column L to show "Questionnaire Completed"

4. **Deploy as Web App**
   - Click "Deploy" → "New deployment"
   - Type: Web app
   - Execute as: Me
   - Who has access: Anyone
   - Click "Deploy"
   - Copy the web app URL

5. **Test**
   - Open web app URL
   - Click "Get My Free Copy"
   - Complete questionnaire
   - Check email for ownership transfer
   - Verify admin sheet shows "Active" status

## ✨ Features

### User Flow
1. User clicks "Get My Free Copy"
2. Enters email address
3. System creates copy (Status: "Pending")
4. Shows 8-question security questionnaire
5. User completes questionnaire
6. System saves answers and transfers ownership (Status: "Active")
7. Success modal shows score with color coding:
   - 🟢 Green (75%+): 6-8 questions answered "Yes"
   - 🟡 Yellow (50-75%): 4-5 questions answered "Yes"
   - 🔴 Red (<50%): 0-3 questions answered "Yes"

### Anti-Duplicate Logic
- If user tries to create another copy while one is pending, shows existing questionnaire
- Only allows new copy after completing questionnaire
- Prevents multiple pending copies per user

### Admin Sheet Structure
```
| User ID | Email | Name | Created Date | Sheet ID | Sheet URL | Sheet Name | Version | Status | App Version | Browser | Questionnaire |
|---------|-------|------|--------------|----------|-----------|------------|---------|--------|-------------|---------|---------------|
| abc123  | user@ | User | 23/10/2025   | 1hM-4Z.. | https://  | CF-V1      | 1       | Active | v2.0        |         | Yes           |
```

### Questionnaire Sheet Format (in copied template)
```
| Date       | Family Awareness | Health Insurance | Term Insurance | Will | Nominees | Emergency Fund | Documents | Access Shared | Score | Total |
|------------|------------------|------------------|----------------|------|----------|----------------|-----------|---------------|-------|-------|
| 23/10/2025 | Yes              | No               | Yes            | No   | Yes      | No             | Yes       | No            | 4     | 8     |
```

## 🎨 Design

- **Theme**: Dark background (#111827) with green accents (#10b981)
- **Font**: 'Segoe UI', Arial, sans-serif
- **Responsive**: Works on desktop, tablet, and mobile
- **No Dependencies**: Pure HTML, CSS, JavaScript

## 🔧 Configuration

### Master Sheet (Admin)
- Tracks all user copies
- Columns: User ID, Email, Name, Date, Sheet ID, URL, Name, Version, Status, App Version, Browser, Questionnaire

### Template Sheet
- The spreadsheet users receive
- Should have all the Capital Friends functionality
- Gets copied to user's Drive after questionnaire

## 📝 Notes

- All user data stays in user's Google Drive
- No backend database required (uses Google Sheets)
- Fully serverless (Google Apps Script)
- No authentication required (uses email for tracking)

## 🐛 Troubleshooting

**Problem**: Copy count shows 0
- **Fix**: Check `MASTER_SHEET_ID` in CONFIG

**Problem**: Questionnaire not resetting
- **Fix**: Already fixed - `resetQuestionnaire()` called on modal close

**Problem**: Duplicate "Status" columns in admin sheet
- **Fix**: Run `fixAdminSheetHeaders()` function once

**Problem**: Old questionnaire format (multi-row)
- **Fix**: This was from old code - new format is single-row

## 📄 License

MIT License - Free to use and modify
