# Master Mutual Fund Database

This folder contains the centralized master database for all Indian mutual funds.

## Files:

### MasterMFDatabase_Standalone.gs
**Main file** - Complete standalone script for the master database Google Sheet.

**Features:**
- Fetches ALL 40,000+ Indian mutual fund schemes from AMFI India
- Auto-refreshes daily at 1 AM IST
- Parses category (Equity, Debt, Hybrid, etc.) and type (Direct, Regular, Growth, etc.)
- Creates MF_Data and MF_Metadata sheets
- No user interaction needed after initial setup

**Columns in MF_Data sheet:**
- Fund Code
- Fund Name
- Category
- NAV
- Date
- Fund House
- Type
- Status

### MASTER_MF_DATABASE_SETUP.md
**Setup guide** - Step-by-step instructions for deploying the master database.

**Includes:**
- How to create a new Google Sheet
- How to add the script
- How to run initial setup
- How to verify data import
- Sharing instructions (public read-only)
- Troubleshooting tips

### MasterMFDatabase_OLD.gs
**Archived** - Older version kept for reference. DO NOT USE.

---

## Deployment:

1. Create new Google Sheet: "Capital Friends V2 - Master MF Database"
2. Open Tools → Script Editor
3. Copy code from **MasterMFDatabase_Standalone.gs**
4. Save and run `setupMasterMFDatabase()`
5. Wait 5-10 minutes for initial data import
6. Share sheet as "Anyone with link - Viewer"
7. Copy Sheet ID for user template configuration

**Current Master DB Sheet ID:** `1pSvGDFTgcCkW6Fk9P2mZ5FSpROVClz7Vu0sW9JnPz9s`

---

## Architecture:

```
Master MF Database (Public, Read-Only)
        ↓ (IMPORTRANGE)
User Template Copies (Private, User's Drive)
```

**Why this architecture?**
- Single source of truth for NAV data
- No API quota per user (IMPORTRANGE is free)
- Automatic daily updates for all users
- Users never need to manually import NAV data
- 100% privacy: User data stays in their Drive

---

## Maintenance:

**Daily:** Script auto-runs at 1 AM IST to refresh NAV data

**Weekly:** Check execution logs for errors

**Monthly:** Verify data accuracy, check for AMFI API changes

---

**Contact:** Jagadeesh Manne | jagadeesh.k.manne@gmail.com
