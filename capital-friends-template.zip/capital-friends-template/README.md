# Capital Friends - Main Template

This folder contains the **complete Capital Friends Apps Script template** that users receive when they click "Make a Copy" from [capitalfriends.in](https://capitalfriends.in).

## What's Included

This is the full-featured Google Sheets template with all functionality:

### Core Features
- Family wealth tracking
- Portfolio management and rebalancing
- Goal planning and tracking
- Insurance policy management
- Bank account tracking
- Mutual fund and stock tracking
- Automated email reports to family members
- Security questionnaire

### Apps Script Files

**Core Logic** (`.js` files):
- `Code.js` - Main entry point
- `Menu.js` - Custom menu system
- `Setup.js` - Initial setup and configuration
- `Triggers.js` - Time-based triggers
- `Utilities.js` - Helper functions

**Feature Modules**:
- `BankAccounts.js` - Bank account management
- `MutualFunds.js` - Mutual fund tracking
- `Stocks.js` - Stock portfolio tracking
- `Goals.js` - Goal planning
- `Insurance.js` - Insurance management
- `Portfolios.js` - Portfolio management
- `Reminders.js` - Reminder system
- `FamilyMembers.js` - Family member management

**Integrations**:
- `MFIntegration.js` - Mutual fund NAV integration
- `EmailReports.js` - Email report generation
- `EmailTemplate.js` - Email templates

**UI Dialogs** (`.html` files):
- `Add*.html` - Forms for adding new entries
- `Edit*.html` - Forms for editing entries
- `Dashboard*.html` - Dashboard views
- `Styles.html` - Shared CSS styles

## Development

### Clone from Apps Script
```bash
clasp clone 1BS0Hzoy7WlCqKvroEGgjTil8DWdGL6A7hWGSl8JjJQOLcjw194VtmpzT
```

### Push changes back to Apps Script
```bash
clasp push
```

### Deploy
```bash
clasp deploy
```

## Related Projects

- **Web App** (`capital-friends-app/`) - Landing page and questionnaire for Google verification
- **Documentation** (`docs/`) - Privacy policy, terms of service, etc.
- **YouTube Videos** (`youtube/`) - Video presentation materials

## License

MIT License - See LICENSE file

## Author

**Jagadeesh Manne**
Email: jagadeeshi.k.manne@gmail.com
GitHub: https://github.com/jagadeeshkmanne/capital-friends
Website: https://capitalfriends.in
